This directory is for a few additional options for YUNG's Better Desert Temples.
Options provided may vary by version.
This directory contains subdirectories for supported versions. The first time you run Better Desert Temples, a version subdirectory will be created if that version supports advanced options.
For example, the first time you use Better Desert Temples for 1.18.2 on Forge, the 'forge-1_18_2' subdirectory will be created in this folder.
If no subdirectory for your version is created, then that version probably does not support the additional options.
NOTE -- MOST OPTIONS CAN BE FOUND IN A CONFIG FILE OUTSIDE THIS FOLDER!
For example, on Forge 1.18.2 the file is 'betterdeserttemples-forge-1_18_2.toml'.