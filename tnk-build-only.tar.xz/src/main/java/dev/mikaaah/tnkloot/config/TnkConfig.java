package dev.mikaaah.tnkloot.config;

import com.google.gson.*;
import dev.mikaaah.tnkloot.TnkLoot;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.fml.loading.FMLPaths;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Server-owned definitions. Invalid edits never replace the active good config. */
public final class TnkConfig {
    public enum Mode { ADVANCEMENTS, FTB_QUESTS, MANUAL, OFF }
    public record Tier(int rank, String id, String name, List<ResourceLocation> advancements) {}
    public record Weapon(String id, int minTier, int maxTier, int weight) {}
    public record Settings(Mode mode, boolean shareFtbTeams, boolean enableIdentification,
                           List<Tier> tiers, List<Weapon> weapons) {
        public int highestTier() { return tiers.stream().mapToInt(Tier::rank).max().orElse(0); }
        public Optional<Tier> tierForName(String id) { return tiers.stream().filter(t -> t.id().equalsIgnoreCase(id)).findFirst(); }
        public Tier tierForRank(int rank) {
            return tiers.stream().filter(t -> t.rank() <= rank)
                .max(Comparator.comparingInt(Tier::rank)).orElse(tiers.getFirst());
        }
    }

    private static volatile Settings CURRENT = defaults();
    private TnkConfig() {}
    public static Settings get() { return CURRENT; }

    public static Path path() {
        return FMLPaths.CONFIGDIR.get().resolve("tnkloot").resolve("tiers.json");
    }

    public static synchronized boolean reload() {
        Path path = path();
        try {
            Files.createDirectories(path.getParent());
            if (Files.notExists(path)) {
                Files.writeString(path, exampleJson(), StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW);
            }
            JsonObject root;
            try (var reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                root = JsonParser.parseReader(reader).getAsJsonObject();
            }
            Mode mode = Mode.valueOf(optString(root, "progression_mode", "ADVANCEMENTS").toUpperCase(Locale.ROOT));
            boolean share = optBool(root, "share_ftb_teams", true);
            boolean identification = optBool(root, "identification_enabled", true);
            List<Tier> tiers = new ArrayList<>();
            Set<Integer> usedRanks = new HashSet<>();
            Set<String> usedIds = new HashSet<>();
            for (JsonElement element : root.getAsJsonArray("tiers")) {
                try {
                    JsonObject e = element.getAsJsonObject();
                    int rank = e.get("rank").getAsInt();
                    String id = e.get("id").getAsString().toLowerCase(Locale.ROOT);
                    if (rank < 0 || !id.matches("[a-z0-9_]+") || !usedRanks.add(rank) || !usedIds.add(id)) {
                        TnkLoot.LOG.warn("Skipping tier with invalid or duplicate rank/id: {}", e);
                        continue;
                    }
                    List<ResourceLocation> advancements = new ArrayList<>();
                    if (e.has("advancements")) for (JsonElement adv : e.getAsJsonArray("advancements")) {
                        ResourceLocation key = ResourceLocation.tryParse(adv.getAsString());
                        if (key != null) advancements.add(key);
                        else TnkLoot.LOG.warn("Skipping invalid advancement ID {}", adv);
                    }
                    tiers.add(new Tier(rank, id, optString(e, "name", id), List.copyOf(advancements)));
                } catch (RuntimeException ex) {
                    TnkLoot.LOG.warn("Skipping invalid tier entry {}: {}", element, ex.toString());
                }
            }
            tiers.sort(Comparator.comparingInt(Tier::rank));
            if (tiers.isEmpty() || tiers.getFirst().rank() != 0) throw new IllegalArgumentException("A rank-0 tier is required");
            List<Weapon> weapons = new ArrayList<>();
            if (root.has("weapons")) for (JsonElement element : root.getAsJsonArray("weapons")) {
                try {
                    JsonObject e = element.getAsJsonObject();
                    String id = e.get("item").getAsString();
                    if (ResourceLocation.tryParse(id) == null) throw new IllegalArgumentException("Invalid item ID");
                    int min = e.get("min_tier").getAsInt();
                    int max = e.has("max_tier") ? e.get("max_tier").getAsInt() : Integer.MAX_VALUE;
                    int weight = e.has("weight") ? e.get("weight").getAsInt() : 1;
                    if (min < 0 || max < min || weight < 1) throw new IllegalArgumentException("Invalid tier range or weight");
                    weapons.add(new Weapon(id, min, max, weight));
                } catch (RuntimeException ex) {
                    TnkLoot.LOG.warn("Skipping invalid weapon entry {}: {}", element, ex.toString());
                }
            }
            CURRENT = new Settings(mode, share, identification, List.copyOf(tiers), List.copyOf(weapons));
            TnkLoot.LOG.info("Loaded {} tiers, {} weapons; mode {}", tiers.size(), weapons.size(), mode);
            return true;
        } catch (Exception ex) {
            TnkLoot.LOG.error("Invalid config {}; keeping last known-good settings", path, ex);
            return false;
        }
    }

    private static boolean optBool(JsonObject root, String name, boolean fallback) {
        return root.has(name) ? root.get(name).getAsBoolean() : fallback;
    }
    private static String optString(JsonObject root, String name, String fallback) {
        return root.has(name) ? root.get(name).getAsString() : fallback;
    }
    private static Settings defaults() {
        return new Settings(Mode.ADVANCEMENTS, true, true,
            List.of(new Tier(0, "novice", "Novice", List.of())), List.of());
    }
    private static String exampleJson() {
        return """
        {
          "progression_mode": "ADVANCEMENTS",
          "share_ftb_teams": true,
          "identification_enabled": true,
          "tiers": [
            {"rank": 0, "id": "novice", "name": "Novice", "advancements": []},
            {"rank": 1, "id": "apprentice", "name": "Apprentice", "advancements": ["minecraft:story/upgrade_tools"]},
            {"rank": 2, "id": "adventurer", "name": "Adventurer", "advancements": ["minecraft:story/smelt_iron"]},
            {"rank": 3, "id": "explorer", "name": "Explorer", "advancements": ["minecraft:story/mine_diamond"]},
            {"rank": 4, "id": "veteran", "name": "Veteran", "advancements": ["minecraft:story/enter_the_nether"]},
            {"rank": 5, "id": "champion", "name": "Champion", "advancements": ["minecraft:nether/obtain_blaze_rod"]},
            {"rank": 6, "id": "hero", "name": "Hero", "advancements": ["minecraft:nether/summon_wither"]},
            {"rank": 7, "id": "legendary", "name": "Legendary", "advancements": ["minecraft:end/kill_dragon"]}
          ],
          "weapons": [
            {"item":"minecraft:wooden_sword", "min_tier":0, "max_tier":1, "weight":5},
            {"item":"minecraft:stone_sword", "min_tier":1, "max_tier":2, "weight":5},
            {"item":"minecraft:iron_sword", "min_tier":2, "max_tier":3, "weight":5},
            {"item":"minecraft:diamond_sword", "min_tier":3, "max_tier":6, "weight":3},
            {"item":"minecraft:netherite_sword", "min_tier":6, "max_tier":7, "weight":2}
          ]
        }
        """;
    }
}
