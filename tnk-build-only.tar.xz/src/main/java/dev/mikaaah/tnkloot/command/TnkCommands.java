package dev.mikaaah.tnkloot.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import dev.mikaaah.tnkloot.config.TnkConfig;
import dev.mikaaah.tnkloot.loot.UnidentifiedWeaponItem;
import dev.mikaaah.tnkloot.progression.ProgressionService;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

import java.util.Collection;

public final class TnkCommands {
    private TnkCommands() {}

    public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("tnkloot")
            .then(Commands.literal("tier")
                .executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    int rank = ProgressionService.getTier(p);
                    ctx.getSource().sendSuccess(() -> Component.literal("Guild tier: " + rank + " (" +
                        TnkConfig.get().tierForRank(rank).name() + "); progression mode " + TnkConfig.get().mode()), false);
                    return rank + 1;
                })
                .then(Commands.literal("list").executes(ctx -> {
                    for (var tier : TnkConfig.get().tiers()) {
                        ctx.getSource().sendSuccess(() -> Component.literal(tier.rank() + " / " + tier.id() + " — " + tier.name()), false);
                    }
                    return TnkConfig.get().tiers().size();
                }))
                .then(Commands.literal("unlock").requires(source -> source.hasPermission(2))
                    .then(Commands.argument("players", EntityArgument.players())
                        .then(Commands.argument("tier", StringArgumentType.word())
                            .executes(ctx -> change(ctx.getSource(), EntityArgument.getPlayers(ctx, "players"),
                                StringArgumentType.getString(ctx, "tier"))))))
                .then(Commands.literal("reset").requires(source -> source.hasPermission(2))
                    .then(Commands.argument("players", EntityArgument.players())
                        .executes(ctx -> {
                            Collection<ServerPlayer> players = EntityArgument.getPlayers(ctx, "players");
                            players.forEach(ProgressionService::reset);
                            ctx.getSource().sendSuccess(() -> Component.literal("Reset Guild tier for " + players.size() + " target(s)"), true);
                            return players.size();
                        }))))
            .then(Commands.literal("reload").requires(source -> source.hasPermission(2)).executes(ctx -> {
                boolean ok = TnkConfig.reload();
                ctx.getSource().sendSuccess(() -> Component.literal(ok ? "T&K loot config reloaded" : "Invalid config; old settings preserved"), true);
                return ok ? 1 : 0;
            }))
            .then(Commands.literal("unidentified").requires(source -> source.hasPermission(2))
                .then(Commands.argument("players", EntityArgument.players())
                    .executes(ctx -> give(ctx.getSource(), EntityArgument.getPlayers(ctx, "players"), null))
                    .then(Commands.argument("tier", StringArgumentType.word())
                        .executes(ctx -> give(ctx.getSource(), EntityArgument.getPlayers(ctx, "players"),
                            StringArgumentType.getString(ctx, "tier")))))));
    }

    private static int parseTier(String token) {
        try {
            int rank = Integer.parseInt(token);
            if (TnkConfig.get().tiers().stream().anyMatch(t -> t.rank() == rank)) return rank;
        } catch (NumberFormatException ignored) { }
        return TnkConfig.get().tierForName(token).map(TnkConfig.Tier::rank).orElse(-1);
    }

    private static int change(net.minecraft.commands.CommandSourceStack source,
                              Collection<ServerPlayer> players, String tierToken) {
        int rank = parseTier(tierToken);
        if (rank < 0) {
            source.sendFailure(Component.literal("Unknown tier '" + tierToken + "'. Use /tnkloot tier list"));
            return 0;
        }
        int count = 0;
        for (var player : players) if (ProgressionService.unlock(player, rank)) count++;
        int changes = count;
        source.sendSuccess(() -> Component.literal("Unlocked tier " + rank + " for " + changes + " target(s)"), true);
        return count;
    }

    private static int give(net.minecraft.commands.CommandSourceStack source,
                            Collection<ServerPlayer> players, String tierToken) {
        int rank = tierToken == null ? -1 : parseTier(tierToken);
        if (tierToken != null && rank < 0) {
            source.sendFailure(Component.literal("Unknown tier '" + tierToken + "'"));
            return 0;
        }
        for (var player : players) {
            int effective = tierToken == null ? ProgressionService.getTier(player) : rank;
            var stack = UnidentifiedWeaponItem.create(effective);
            if (!player.getInventory().add(stack)) player.drop(stack, false);
        }
        source.sendSuccess(() -> Component.literal("Given unidentified weapons to " + players.size() + " target(s)"), true);
        return players.size();
    }
}
