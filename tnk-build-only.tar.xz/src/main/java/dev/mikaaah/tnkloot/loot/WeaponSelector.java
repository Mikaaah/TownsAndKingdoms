package dev.mikaaah.tnkloot.loot;

import dev.mikaaah.tnkloot.TnkLoot;
import dev.mikaaah.tnkloot.config.TnkConfig;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.List;

/** Weighted data-driven pool. Missing mod items are skipped rather than crashing identification. */
public final class WeaponSelector {
    private WeaponSelector() {}

    public static ItemStack roll(Level level, int tier) {
        List<TnkConfig.Weapon> pool = new ArrayList<>();
        long total = 0;
        for (var weapon : TnkConfig.get().weapons()) {
            if (tier < weapon.minTier() || tier > weapon.maxTier()) continue;
            ResourceLocation id = ResourceLocation.tryParse(weapon.id());
            if (id == null || !BuiltInRegistries.ITEM.containsKey(id)) continue;
            Item item = BuiltInRegistries.ITEM.get(id);
            if (item == Items.AIR) continue;
            pool.add(weapon);
            total += weapon.weight();
        }
        if (total == 0) return ItemStack.EMPTY;
        long choice = Math.floorMod(level.getRandom().nextLong(), total);
        for (var weapon : pool) {
            choice -= weapon.weight();
            if (choice < 0) return new ItemStack(BuiltInRegistries.ITEM.get(ResourceLocation.parse(weapon.id())));
        }
        TnkLoot.LOG.warn("Weighted pool selection unexpectedly ran out of items");
        return ItemStack.EMPTY;
    }
}
