// Native NeoForge lava/water placement. No tick scanner, global coordinate cache or forced chunks.
(function () {
  const FluidPlacement = Java.loadClass('net.neoforged.neoforge.event.level.BlockEvent$FluidPlaceBlockEvent');
  const Registries = Java.loadClass('net.minecraft.core.registries.BuiltInRegistries');
  const selectors = [{"stone": "minecraft:andesite", "lens": "minecraft:polished_andesite", "frame": "kubejs:tk3_kinetic_machine"}, {"stone": "minecraft:diorite", "lens": "minecraft:quartz_block", "frame": "kubejs:tk3_kinetic_machine"}, {"stone": "minecraft:granite", "lens": "minecraft:bricks", "frame": "kubejs:tk3_kinetic_machine"}, {"stone": "create:limestone", "lens": "minecraft:calcite", "frame": "kubejs:tk3_kinetic_machine"}, {"stone": "create:scoria", "lens": "minecraft:netherrack", "frame": "kubejs:tk3_hydraulic_machine"}, {"stone": "create:scorchia", "lens": "minecraft:blackstone", "frame": "kubejs:tk3_hydraulic_machine"}, {"stone": "create:veridium", "lens": "minecraft:copper_block", "frame": "kubejs:tk3_hydraulic_machine"}, {"stone": "create:crimsite", "lens": "minecraft:iron_block", "frame": "kubejs:tk3_hydraulic_machine"}, {"stone": "create:asurine", "lens": "create:zinc_block", "frame": "kubejs:tk3_precision_machine"}, {"stone": "create:ochrum", "lens": "minecraft:gold_block", "frame": "kubejs:tk3_precision_machine"}];
  function id(state) { return String(Registries.BLOCK.getKey(state.getBlock())); }
  NativeEvents.onEvent(FluidPlacement, event => {
    const level = event.getLevel();
    if (level.getServer() == null || event.isCanceled()) return;
    const generated = id(event.getNewState());
    if (generated !== 'minecraft:cobblestone' && generated !== 'minecraft:stone') return;
    const pos = event.getPos();
    const lens = id(level.getBlockState(pos.below()));
    const frame = id(level.getBlockState(pos.below(2)));
    selectors.forEach(entry => {
      if (entry.lens === lens && entry.frame === frame) {
        event.setNewState(Block.getBlock(entry.stone).defaultBlockState());
      }
    });
  });
})();
